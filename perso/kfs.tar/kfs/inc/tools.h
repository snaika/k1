#ifndef HEADER_TOOLS
#define HEADER_TOOLS

int strlen(void);

#endif
