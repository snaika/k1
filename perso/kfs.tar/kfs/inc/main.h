#ifndef HEADER_MAIN
#define HEADER_MAIN

#define	NULL			0
#define	MAGIC_NUMBER		0x2BADB002

void	printk(const char *string);

#endif
