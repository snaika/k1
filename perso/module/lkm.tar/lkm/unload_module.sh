sudo rmmod version.ko
dmesg | tail -1
make clean
