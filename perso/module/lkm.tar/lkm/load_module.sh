make
sudo insmod version.ko
dmesg | tail -n 3
