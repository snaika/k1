rmmod rootkit.ko
