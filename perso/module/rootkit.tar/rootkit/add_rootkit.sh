insmod rootkit.ko
